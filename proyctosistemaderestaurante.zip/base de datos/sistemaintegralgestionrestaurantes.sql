-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-06-2025 a las 02:16:17
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sistemaintegralgestionrestaurantes`
--
CREATE DATABASE IF NOT EXISTS `sistemaintegralgestionrestaurantes` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `sistemaintegralgestionrestaurantes`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `idUsuario` int(11) NOT NULL,
  `telefonoContacto` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`idUsuario`, `telefonoContacto`) VALUES
(101, '3023422919'),
(104, '3101234567'),
(106, '3119876543'),
(107, '3121122334'),
(108, '3135566778');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalleventa`
--

CREATE TABLE `detalleventa` (
  `idVenta` int(11) NOT NULL,
  `idProducto` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalleventa`
--

INSERT INTO `detalleventa` (`idVenta`, `idProducto`, `cantidad`, `subtotal`) VALUES
(5002, 2, 1, 4000.00),
(5002, 3, 1, 2500.00),
(5003, 4, 1, 3000.00),
(5004, 5, 1, 3500.00),
(5005, 1, 1, 9500.00),
(5005, 2, 1, 4000.00),
(5007, 1, 2, 19000.00),
(5007, 2, 3, 12000.00),
(5008, 1, 40, 380000.00),
(5008, 2, 20, 80000.00),
(5009, 1, 2, 19000.00),
(5009, 2, 6, 24000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `incluye`
--

CREATE TABLE `incluye` (
  `idReporte` int(11) NOT NULL,
  `idVenta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `incluye`
--

INSERT INTO `incluye` (`idReporte`, `idVenta`) VALUES
(3, 5003),
(4, 5004),
(5, 5005),
(6, 5006),
(7, 5007),
(8, 5008),
(9, 5009);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `insumo`
--

CREATE TABLE `insumo` (
  `idInsumo` int(11) NOT NULL,
  `nombre` varchar(40) DEFAULT NULL,
  `unidadMedida` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `insumo`
--

INSERT INTO `insumo` (`idInsumo`, `nombre`, `unidadMedida`) VALUES
(201, 'Pan', 'unidad'),
(202, 'Carne', 'gramos'),
(203, 'Queso', 'gramos'),
(204, 'Mango', 'unidad'),
(205, 'Harina', 'gramos'),
(206, 'Papa', 'gramos'),
(207, 'Aceite', 'ml');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `idProducto` int(11) NOT NULL,
  `nombre` varchar(40) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `idAdministrador` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`idProducto`, `nombre`, `precio`, `idAdministrador`) VALUES
(1, 'Hamburguesa Sencilla', 9500.00, 101),
(2, 'Jugo de Mango', 4000.00, 101),
(3, 'Empanada de Queso', 2500.00, 101),
(4, 'Gaseosa Personal', 3000.00, 101),
(5, 'Papas Fritas Pequeñas', 3500.00, 104);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productoinsumo`
--

CREATE TABLE `productoinsumo` (
  `idProducto` int(11) NOT NULL,
  `idInsumo` int(11) NOT NULL,
  `cantidadRequerida` decimal(6,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productoinsumo`
--

INSERT INTO `productoinsumo` (`idProducto`, `idInsumo`, `cantidadRequerida`) VALUES
(1, 201, 2.00),
(1, 202, 150.00),
(1, 203, 50.00),
(1, 205, 40.00),
(2, 204, 1.00),
(3, 203, 30.00),
(3, 205, 100.00),
(5, 206, 200.00),
(5, 207, 50.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reporteventa`
--

CREATE TABLE `reporteventa` (
  `idReporte` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `idAdministrador` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reporteventa`
--

INSERT INTO `reporteventa` (`idReporte`, `fecha`, `idAdministrador`) VALUES
(2, '2024-05-21', 101),
(3, '2024-05-23', 104),
(4, '2024-05-20', 101),
(5, '2024-05-24', 106),
(6, '2025-06-18', NULL),
(7, '2025-06-18', NULL),
(8, '2025-06-18', NULL),
(9, '2025-06-18', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `stockinsumo`
--

CREATE TABLE `stockinsumo` (
  `idInsumo` int(11) NOT NULL,
  `cantidadDisponible` decimal(8,2) DEFAULT NULL,
  `puntoReposicion` decimal(8,2) DEFAULT NULL,
  `fechaActualizacion` date DEFAULT NULL,
  `idAdministrador` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `stockinsumo`
--

INSERT INTO `stockinsumo` (`idInsumo`, `cantidadDisponible`, `puntoReposicion`, `fechaActualizacion`, `idAdministrador`) VALUES
(201, 120.00, 20.00, '2024-05-21', 101),
(202, 1500.00, 500.00, '2024-05-21', 101),
(203, 800.00, 200.00, '2024-05-21', 101),
(205, 3500.00, 1000.00, '2024-05-21', 101),
(206, 5000.00, 1000.00, '2024-05-23', 104),
(207, 2000.00, 502.00, '2025-06-16', 104);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `nombreUsuario` varchar(30) DEFAULT NULL,
  `contraseña` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`idUsuario`, `nombre`, `nombreUsuario`, `contraseña`) VALUES
(101, 'Andrés Martínez', 'amartinez', 'AndMart!2024'),
(102, 'Luisa Gómez', 'lgomez', 'LuGo#567'),
(103, 'Carlos Pérez', 'cperez', 'Cperez89!'),
(104, 'Ana Torres', 'atorres', 'AnaT#2025'),
(105, 'David Rojas', 'drojas', 'DRoj@s123'),
(106, 'Laura Vargas', 'lvargas', 'LaVaG&432'),
(107, 'Sofia Castro', 'scastro', 'SoCa%321'),
(108, 'Martin Rey', 'mrey', 'MaReY$789'),
(109, 'Elena Paez', 'epaez', 'ElPaEz#987'),
(110, 'Juan Silva', 'jsilva', 'JuSiLv@654'),
(200, 'jose', 'joseuser', '123fsdfds');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vendedor`
--

CREATE TABLE `vendedor` (
  `idUsuario` int(11) NOT NULL,
  `turno` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vendedor`
--

INSERT INTO `vendedor` (`idUsuario`, `turno`) VALUES
(102, '8:00 a.m. a 10:00 a.m.'),
(103, '10:00 a.m. a 1:00 p.m.'),
(105, '1:00 p.m. a 4:00 p.m.'),
(109, '4:00 p.m. a 7:00 p.m.'),
(110, '7:00 p.m. a 10:00 p.m.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `venta`
--

CREATE TABLE `venta` (
  `idVenta` int(11) NOT NULL,
  `fechaHora` datetime DEFAULT NULL,
  `totalVenta` decimal(10,2) DEFAULT NULL,
  `idVendedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `venta`
--

INSERT INTO `venta` (`idVenta`, `fechaHora`, `totalVenta`, `idVendedor`) VALUES
(5002, '2024-05-22 12:45:00', 6500.00, 103),
(5003, '2024-05-23 14:30:00', 3000.00, 105),
(5004, '2024-05-23 17:00:00', 3500.00, 109),
(5005, '2024-05-23 19:15:00', 13500.00, 110),
(5006, '2025-06-18 10:03:06', 39000.00, 110),
(5007, '2025-06-18 11:21:29', 31000.00, 110),
(5008, '2025-06-18 11:24:01', 460000.00, 110),
(5009, '2025-06-18 11:36:27', 43000.00, 110);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`idUsuario`);

--
-- Indices de la tabla `detalleventa`
--
ALTER TABLE `detalleventa`
  ADD PRIMARY KEY (`idVenta`,`idProducto`),
  ADD KEY `idProducto` (`idProducto`);

--
-- Indices de la tabla `incluye`
--
ALTER TABLE `incluye`
  ADD PRIMARY KEY (`idReporte`,`idVenta`),
  ADD KEY `idVenta` (`idVenta`);

--
-- Indices de la tabla `insumo`
--
ALTER TABLE `insumo`
  ADD PRIMARY KEY (`idInsumo`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`idProducto`),
  ADD KEY `idAdministrador` (`idAdministrador`);

--
-- Indices de la tabla `productoinsumo`
--
ALTER TABLE `productoinsumo`
  ADD PRIMARY KEY (`idProducto`,`idInsumo`),
  ADD KEY `idInsumo` (`idInsumo`);

--
-- Indices de la tabla `reporteventa`
--
ALTER TABLE `reporteventa`
  ADD PRIMARY KEY (`idReporte`),
  ADD KEY `idAdministrador` (`idAdministrador`);

--
-- Indices de la tabla `stockinsumo`
--
ALTER TABLE `stockinsumo`
  ADD PRIMARY KEY (`idInsumo`),
  ADD KEY `idAdministrador` (`idAdministrador`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idUsuario`),
  ADD UNIQUE KEY `nombreUsuario` (`nombreUsuario`);

--
-- Indices de la tabla `vendedor`
--
ALTER TABLE `vendedor`
  ADD PRIMARY KEY (`idUsuario`);

--
-- Indices de la tabla `venta`
--
ALTER TABLE `venta`
  ADD PRIMARY KEY (`idVenta`),
  ADD KEY `idVendedor` (`idVendedor`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `insumo`
--
ALTER TABLE `insumo`
  MODIFY `idInsumo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=224;

--
-- AUTO_INCREMENT de la tabla `reporteventa`
--
ALTER TABLE `reporteventa`
  MODIFY `idReporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `venta`
--
ALTER TABLE `venta`
  MODIFY `idVenta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5010;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD CONSTRAINT `administrador_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`);

--
-- Filtros para la tabla `detalleventa`
--
ALTER TABLE `detalleventa`
  ADD CONSTRAINT `detalleventa_ibfk_1` FOREIGN KEY (`idVenta`) REFERENCES `venta` (`idVenta`),
  ADD CONSTRAINT `detalleventa_ibfk_2` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`);

--
-- Filtros para la tabla `incluye`
--
ALTER TABLE `incluye`
  ADD CONSTRAINT `incluye_ibfk_1` FOREIGN KEY (`idReporte`) REFERENCES `reporteventa` (`idReporte`),
  ADD CONSTRAINT `incluye_ibfk_2` FOREIGN KEY (`idVenta`) REFERENCES `venta` (`idVenta`);

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`idAdministrador`) REFERENCES `administrador` (`idUsuario`);

--
-- Filtros para la tabla `productoinsumo`
--
ALTER TABLE `productoinsumo`
  ADD CONSTRAINT `productoinsumo_ibfk_1` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`),
  ADD CONSTRAINT `productoinsumo_ibfk_2` FOREIGN KEY (`idInsumo`) REFERENCES `insumo` (`idInsumo`);

--
-- Filtros para la tabla `reporteventa`
--
ALTER TABLE `reporteventa`
  ADD CONSTRAINT `reporteventa_ibfk_1` FOREIGN KEY (`idAdministrador`) REFERENCES `administrador` (`idUsuario`);

--
-- Filtros para la tabla `stockinsumo`
--
ALTER TABLE `stockinsumo`
  ADD CONSTRAINT `stockinsumo_ibfk_1` FOREIGN KEY (`idInsumo`) REFERENCES `insumo` (`idInsumo`),
  ADD CONSTRAINT `stockinsumo_ibfk_2` FOREIGN KEY (`idAdministrador`) REFERENCES `administrador` (`idUsuario`);

--
-- Filtros para la tabla `vendedor`
--
ALTER TABLE `vendedor`
  ADD CONSTRAINT `vendedor_ibfk_1` FOREIGN KEY (`idUsuario`) REFERENCES `usuario` (`idUsuario`);

--
-- Filtros para la tabla `venta`
--
ALTER TABLE `venta`
  ADD CONSTRAINT `venta_ibfk_1` FOREIGN KEY (`idVendedor`) REFERENCES `vendedor` (`idUsuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
