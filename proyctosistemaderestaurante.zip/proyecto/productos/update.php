<?php
include("conexion.php");
$con = conectar();
$idInsumo_ = $_POST['idInsumo'];
$idInsumoNUEVO_ = $_POST['idInsumoNUEVO'];
$idProducto_ = $_POST['idProducto'];
$cantidadRequerida_ = $_POST['cantidadRequerida'];

$sql0 ="UPDATE productoinsumo SET idInsumo='$idInsumoNUEVO_',cantidadRequerida ='$cantidadRequerida_'
       WHERE idInsumo='$idInsumo_' and idProducto='$idProducto_'";
$query0 = mysqli_query($con, $sql0);
$result = mysqli_query($con,"SELECT nombre FROM producto where idProducto= '$idProducto_'");
    $row = mysqli_fetch_assoc($result);
 $nombreProducto_=  $row['nombre'];


if ($query0) {
    header("Location: productoinsumo.php?idProducto=$idProducto_&nombreProducto=".urlencode($nombreProducto_)."&registro=ok");
} else {
    echo "Error al actualizar: " . mysqli_error($con);
}
?>