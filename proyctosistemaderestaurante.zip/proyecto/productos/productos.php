<?php
session_start();
include("conexion.php");
 $conexion = conectar();
     $result = mysqli_query($conexion,"SELECT * FROM producto");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>productos</title>
     <!-- Incluye Bootstrap Icons  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

                 <!-- Bootstrap 5 CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                 <!-- Bootstrap 5 JS -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
     <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">

     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
      <style>
            thead.bg-purple th {
            background-color: #6f42c1 !important;
            color: white !important;
            }

            table tbody tr:hover {
            background-color: #f3e8ff !important;
            cursor: pointer;
             }
         </style> 
   
        <script>
        $(document).ready(function() {
            $('#productos').DataTable({
                "lengthMenu": [[5, 10, 50, -1], [5, 10, 50, "Todos"]]
            });
        });
    </script>
      </script>
    <script type="text/javascript">
        function confirmDelete() {
            var respuesta = confirm("¿Seguro que desea borrar?");
            if (respuesta) {
                alert("Registro Borrado");
                return true;
            } else {
                alert("Ha decidido no borrar el registro");
                return false;
            }
        }
    </script>
    <script>
    window.onload = function () {
        const params = new URLSearchParams(window.location.search);
        if (params.get("registro") === "ok") {
            const toastEl = document.getElementById('liveToast');
            const toast = new bootstrap.Toast(toastEl);
            toast.show();

            // Elimina el parámetro ?registro=ok de la URL sin recargar la página
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    };
    </script>
     </script>
   
   
</head>
<header>
    <nav class="navbar navbar-dark bg-dark text-white px-4" style="height: 60px;">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <span class="navbar-brand mb-0 h5">🗃️ INFORMACION DE PRODUCTOS</span>
    <div class="d-flex align-items-center gap-3">
      <span>👤 Usuario: <strong><?php echo $_SESSION['usuario'];?></strong></span>
      <span>🆔 Código: <strong><?php echo  $_SESSION['idUsuario'];?></strong></span>
    </div>
  </div>
</nav>
</header>

<body>
  <div style="min-height: 100vh;background-image: url('comida.jpg'); background-size: cover;  background-repeat: no-repeat; background-position: center; padding: 20px;">
    
     <div class="content">
         <div class="container mt-2">
            <div class="row">
                <!-- Formulario -->
                <div class="col-md-3">
                     <h1><span class="badge bg-dark">nuevo producto</span></h1>

                        <div class="bg-white p-4 rounded shadow">
                            <form action="insertar.php" method="POST">
                                <input type="text" class="form-control mb-3" name="idProducto_" placeholder="id del producto" required>
                                <input type="text" class="form-control mb-3" name="nombre_" placeholder="nombre" required>
                                <input type="text" class="form-control mb-3" name="precio_" placeholder="precio por unidad" required>
                                <input type="submit" class="btn btn-primary" value="Guardar">
                            </form>
                        </div>
                </div>
                
                <!-- Tabla -->
             <div class="col-md-9">
               <!-- Tabla mejorada -->
                <table id="productos" class="table table-striped table-bordered table-hover shadow-lg mt-4">
                 <thead class="bg-purple text-center">
                   <tr>
                     <th >ID producto</th>
                     <th>Nombre</th>
                     <th >precio</th>
                     <th >administrador creador</th>
                     <th>info insumos</th>
                     <th>borrar</th>
                   </tr>
                 </thead>
                 <tbody>
                   <?php while($row = mysqli_fetch_assoc($result)) { ?>
                   <tr>
                     <td><?php echo htmlspecialchars($row['idProducto']); ?></td>
                     <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                     <td><?php echo htmlspecialchars($row['precio']); ?></td>
                     <td><?php echo htmlspecialchars($row['idAdministrador']); ?></td>
                      <td class="text-center">
                                        <a href="productoinsumo.php?idProducto=<?php echo urlencode($row['idProducto']); ?>&nombreProducto=<?php echo urlencode($row['nombre']); ?>">
                                            <button type="button" class="btn btn-info">revisar</button>
                                        </a>
                                    </td>
                                    <td class="text-center">
                                        <a href="delete.php?idProducto=<?php echo urlencode($row['idProducto']); ?>" onclick="return confirmDelete()">
                                            <button type="button" class="btn btn-danger">Eliminar</button>
                                        </a>
                      </td>   
                   </tr>
                   <?php } ?>
                 </tbody>
               </table>
                    
        </div>
     <div class="position-fixed bottom-0 start-0 m-3">
       <a href="../index.php" class="btn btn-secondary m-3">
       <i class="bi bi-arrow-left-circle"></i> volver atras
       </a>
       <a href="../login.html" class="btn btn-outline-primary">
       <i class="bi bi-house-door-fill"></i> cerrar sesion
       </a>
       </div>
    </div>
     <?php mysqli_close($conexion); ?> 
    <!-- mensaje de exito de registro -->
     <div class="toast-container position-fixed bottom-0 end-0 p-3">
  <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header bg-success text-white">
      <strong class="me-auto">Éxito</strong>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Cerrar"></button>
    </div>
    <div class="toast-body">
      ¡registro agregado correctamente!
    </div>
  </div>
</div>
  </div>
</body>
</html>