<?php

include("conexion.php");
$con=conectar();

$idInsumo_=$_GET['idInsumo'];
$idProducto_=$_GET['idProducto'];
$sql="DELETE FROM productoinsumo  WHERE idProducto='$idProducto_' and idInsumo='$idInsumo_'";
$result = mysqli_query($con,"SELECT nombre FROM producto where idProducto= '$idProducto_'");
    $row = mysqli_fetch_assoc($result);
 $nombreProducto_=  $row['nombre'];
$query=mysqli_query($con,$sql);
if($query)
{ 
header("Location: productoinsumo.php?idProducto=$idProducto_&nombreProducto=".urlencode($nombreProducto_)."&registro=no");
}
?>