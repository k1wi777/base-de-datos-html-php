<?php

include("conexion.php");
$con=conectar();

$idProducto_=$_GET['idProducto'];
$sql="DELETE FROM productoinsumo  WHERE idProducto='$idProducto_'";
$sql0="DELETE FROM producto  WHERE idProducto='$idProducto_'";
$query=mysqli_query($con,$sql);
$query0=mysqli_query($con,$sql0);
if($query and $query0 )
{ 
Header("Location: productos.php");
}
?>