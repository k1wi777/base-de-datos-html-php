<?php
include("conexion.php");
$con = conectar();

$idInsumo_ = $_POST['idInsumo'];
$idProducto_ = $_POST['idProducto'];
$cantidadRequerida_ = $_POST['cantidadRequerida'];
$sql="DELETE FROM productoinsumo  WHERE idProducto='$idProducto_' and idInsumo='$idInsumo_'";
$result = mysqli_query($con,"SELECT nombre FROM producto where idProducto= '$idProducto_'");
    $row = mysqli_fetch_assoc($result);
 $nombreProducto_=  $row['nombre'];

 $sql0 = "INSERT INTO productoInsumo (idInsumo,idProducto,cantidadRequerida) VALUES ('$idInsumo_', '$idProducto_','$cantidadRequerida_ ')";
    
    $query0 = mysqli_query($con, $sql0);
    if ($query0) {
       header("Location: productoinsumo.php?idProducto=$idProducto_&nombreProducto=".urlencode($nombreProducto_)."&registro=ok");
        exit;
    } else {
        echo '<div class="container mt-4">
                <div class="alert alert-warning" role="alert">
                    Error en el ingreso del registro
                </div>
                <button class="btn btn-secondary" onClick="history.go(-1);">Volver</button>
              </div>';
    }
?>