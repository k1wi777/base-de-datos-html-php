<?php
session_start();
include("conexion.php");
$con = conectar();
$idInsumo_=$_GET['idInsumo'];
$idProducto_=$_GET['idProducto'];
$sql = "SELECT *  FROM productoinsumo   WHERE idInsumo = '$idInsumo_' and idProducto = '$idProducto_'";
$query = mysqli_query($con, $sql);
$row = mysqli_fetch_assoc($query);
 // Consulta para llenar el combo de insumos
    $result2 = mysqli_query($con, "SELECT idInsumo, nombre FROM insumo") or die('No pudo conectar a la consulta');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>editar stock</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<header>
    <nav class="navbar navbar-dark bg-dark text-white px-4" style="height: 60px;">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <span class="navbar-brand mb-0 h5">✏️ EDICION DE INSUMO</span>
    <div class="d-flex align-items-center gap-3">
      <span>👤 Usuario: <strong><?php echo $_SESSION['usuario'];?></strong></span>
      <span>🆔 Código: <strong><?php echo  $_SESSION['idUsuario'];?></strong></span>
    </div>
  </div>
</nav>
</header>
<body>
    <div style="min-height: 100vh;background-image: url('insumos.jpg'); background-size: cover;  background-repeat: no-repeat; background-position: center; padding: 20px;">
    <!-- 
     -->

    <div class="container mt-5">
        <h1><span class="badge bg-dark">Editar datos de un insumo </span></h1>
  <div class="bg-white p-4 rounded shadow">
    <form action="update.php" method="POST">
         <input type="hidden" name="idInsumo" value="<?php echo $idInsumo_ ?>">
          <input type="hidden" name="idProducto" value="<?php echo $idProducto_ ?>">
        <div class="mb-3">
           
          <label><h6>insumo</h6></label>
                                <select name="idInsumoNUEVO" class="form-control mb-3" required>
                                   <?php while ($valores = mysqli_fetch_array($result2)) { ?>
                                       <option value="<?php echo $valores['idInsumo']; ?>"
                                           <?php if ($valores['idInsumo'] == $idInsumo_) echo 'selected'; ?>>
                                           <?php echo $valores['nombre']; ?>
                                       </option>
                                   <?php } ?>
                                </select>
        </div>
        <div class="mb-3">
            <label><h6>cantidad requerida</h6></label>
            <input type="text" class="form-control" name="cantidadRequerida" value="<?php echo $row['cantidadRequerida'] ?>" required>
        </div>
        <input type="submit" class="btn btn-primary" value="Actualizar">
        <a href="javascript:history.back()" class="btn btn-secondary">Cancelar</a>
    </form>
  </div>
</div>
</div>
  <?php mysqli_close($con); ?> 
</body>
</html>