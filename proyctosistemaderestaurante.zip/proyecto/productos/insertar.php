<?php
session_start();
include("conexion.php");
$con = conectar();

$idProducto_ = $_POST['idProducto_'];
$nombre_ = $_POST['nombre_'];
$precio_ = $_POST['precio_'];
$idAdministrador_=$_SESSION['idUsuario'];

 $sql0 = "INSERT INTO producto (idProducto,nombre,precio,idAdministrador) VALUES ('$idProducto_', '$nombre_','$precio_','$idAdministrador_')";
    
    $query0 = mysqli_query($con, $sql0);
    if ($query0) {
        header("Location: productos.php"."?registro=ok");
        exit;
    } else {
        echo '<div class="container mt-4">
                <div class="alert alert-warning" role="alert">
                    Error en el ingreso del registro
                </div>
                <button class="btn btn-secondary" onClick="history.go(-1);">Volver</button>
              </div>';
    }
?>