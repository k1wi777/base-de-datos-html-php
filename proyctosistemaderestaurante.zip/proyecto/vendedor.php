<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>perfil vendedor</title>
    <link rel="stylesheet" href="estilos.css">
    
    <style>
body {
  overflow-y: hidden;
}
</style>
<style>
    .btn-cerrar-sesion {
      position: fixed;
      bottom: 20px;
      left: 20px;
      background-color:rgb(193, 66, 176); /* Morado */
      color: white;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      border-radius: 5px;
      cursor: pointer;
      box-shadow: 0 4px 6px rgba(0,0,0,0.2);
      transition: background-color 0.3s ease;
      text-decoration: none;
    }

    .btn-cerrar-sesion:hover {
      background-color:rgb(163, 50, 148); /* Morado oscuro */
    }
  </style>
</head>
<body class="fondo-alt" >

     
    <!-- creando menu de navegacion -->
     <header>
        <div class="content">
            
            <div class="menu container">
                <a class="logo">vendedor: <?php echo $_SESSION['usuario'];?></a>
                <a class="logo"><?php echo " ID: " .  $_SESSION['idUsuario'];?></a>
            <input type="checkbox" id="menu"/>
            <label for="menu">
               <img src="imagenes/menu.png" class="menu-icono" alt="">
            </label>
                <nav class="navbar">
                    <!-- creando una lista  de items -->
                    <ul class="navbar-nav">
                    <!-- items de la barra de menu -->
                    <li>  <a href="ventas/realizarventas.php">relizar venta</a> </li>
                    <li>  <a href="ventas/ventasrealizadas.php">ventas realizadas</a> </li>
                    

                    </ul>
                </nav>
            </div>


        </div>


     </header>
     
    <div class="pag" >
       <h1>REALIZAR TAREAS VENDEDOR</h1>
       <br>
       <H3>registrar una compra</h3>
        <h3>revisar todas tus ventas hechas</H3>
   </div>
    <a href="login.html" class="btn-cerrar-sesion">Cerrar sesión</a>
</body>
</html>