<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>perfil administrador</title>
    <link rel="stylesheet" href="estilos.css">
    
    <style>
body {
  overflow-y: hidden;
}
</style>
<style>
    .btn-cerrar-sesion {
      position: fixed;
      bottom: 20px;
      left: 20px;
      background-color: #6f42c1; /* Morado */
      color: white;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      border-radius: 5px;
      cursor: pointer;
      box-shadow: 0 4px 6px rgba(0,0,0,0.2);
      transition: background-color 0.3s ease;
      text-decoration: none;
    }

    .btn-cerrar-sesion:hover {
      background-color: #5a32a3; /* Morado oscuro */
    }
  </style>
</head>

     <!-- colocar una imagen de fondo -->
     <div style="background-image: url('imgenes/fondo3.jpg')"></div>
    <!-- creando menu de navegacion -->
     <header>
        <div class="content">
            
            <div class="menu container">
                <a class="logo">administrador: <?php echo $_SESSION['usuario'];?></a>
                <a class="logo"><?php echo "tu ID: " .  $_SESSION['idUsuario'];?></a>
            <input type="checkbox" id="menu"/>
            <label for="menu">
               <img src="imagenes/menu.png" class="menu-icono" alt="">
            </label>
                <nav class="navbar">
                    <!-- creando una lista  de items -->
                    <ul class="navbar-nav">
                    <!-- items de la barra de menu -->
                    <li>  <a href="stock/stock.php">stock</a> </li>
                    <li>  <a href="reporteVentas/reporteVentas.php">reporte de ventas</a> </li>
                    <li>  <a href="productos/productos.php">productos</a> </li> 
                    

                    </ul>
                </nav>
            </div>


        </div>


     </header>
     
    <div class="pag" >
       <h1>GESTION DE RESTAURANTES</h1>
       <br>
       <H3>consulta de ventas</h3>
        <h3>registro y edicion de productos</H3>
           <h3>gestionar inventario</H3> 
   </div>
    <a href="login.html" class="btn-cerrar-sesion">Cerrar sesión</a>
</body>
</html>