<?php
include("conexion.php");
$con = conectar();

$idInsumo_ = $_POST['idInsumo_'];
$nombre_ = $_POST['nombre_'];
$unidadMedida_ = $_POST['unidadMedida_'];
$puntoReposicion_ = $_POST['puntoReposicion_'];
$cantidadDisponible_ = $_POST['cantidadDisponible_'];

$sql0 ="UPDATE insumo SET nombre='$nombre_',unidadMedida ='$unidadMedida_'WHERE idInsumo='$idInsumo_'";
$sql = "UPDATE stockinsumo SET puntoReposicion ='$puntoReposicion_',cantidadDisponible ='$cantidadDisponible_',fechaActualizacion =CURDATE() WHERE idInsumo='$idInsumo_'";
$query0 = mysqli_query($con, $sql0);
$query = mysqli_query($con, $sql);


if ($query) {
    header("Location: stock.php");
} else {
    echo "Error al actualizar: " . mysqli_error($con);
}
?>
