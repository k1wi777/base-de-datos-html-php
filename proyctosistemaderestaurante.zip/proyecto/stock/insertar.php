
<?php
session_start(); 
include("conexion.php");
$con = conectar();

$nombre_ = $_POST['nombre_'];
$unidadMedida_ = $_POST['unidadMedida_'];
$puntoReposicion_ = $_POST['puntoReposicion_'];
$cantidadDisponible_ = $_POST['cantidadDisponible_'];
$idAdministrador_=$_SESSION['idUsuario'];

    $sql0 = "INSERT INTO insumo (nombre,unidadMedida) VALUES ('$nombre_', '$unidadMedida_')";
    
    $query0 = mysqli_query($con, $sql0);

    if ($query0) {
        $idGenerado = mysqli_insert_id($con);
        $sql = "INSERT INTO stockinsumo (idInsumo,puntoReposicion,cantidadDisponible,fechaActualizacion,idAdministrador) VALUES ('$idGenerado','$puntoReposicion_', '$cantidadDisponible_', CURDATE(),'$idAdministrador_')";
        $query0 = mysqli_query($con, $sql);
        
        header("Location: ".$_SERVER['HTTP_REFERER']."?registro=ok");
        exit;
    } else {
        echo '<div class="container mt-4">
                <div class="alert alert-warning" role="alert">
                    Error en el ingreso del registro
                </div>
                <button class="btn btn-secondary" onClick="history.go(-1);">Volver</button>
              </div>';
    }

?>
