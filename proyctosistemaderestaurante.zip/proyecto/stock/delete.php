<?php

include("conexion.php");
$con=conectar();

$idInsumo_=$_GET['idInsumo_'];
$sql="DELETE FROM stockinsumo  WHERE idInsumo='$idInsumo_'";
$sql0="DELETE FROM insumo  WHERE idInsumo='$idInsumo_'";
$query=mysqli_query($con,$sql);
$query0=mysqli_query($con,$sql0);
if($query and $query0)
{ 
Header("Location: stock.php");
}
?>

