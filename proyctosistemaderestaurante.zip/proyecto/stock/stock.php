<?php
session_start(); 
include("conexion.php");
 $conexion = conectar();
     $result = mysqli_query($conexion,"SELECT stockinsumo.*,insumo.nombre,insumo.unidadMedida 
     FROM stockinsumo
     join insumo on stockinsumo.idInsumo=insumo.idInsumo");


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>administracion de stocks</title>
     <!-- Estilos -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">
     <!-- Incluye Bootstrap Icons  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

                 <!-- Bootstrap 5 CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                 <!-- Bootstrap 5 JS -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#stocks').DataTable({
                "lengthMenu": [[5, 10, 50, -1], [5, 10, 50, "Todos"]]
            });
        });
    </script>

    <script type="text/javascript">
        function confirmDelete() {
            var respuesta = confirm("¿Seguro que desea borrar?");
            if (respuesta) {
                alert("Registro Borrado");
                return true;
            } else {
                alert("Ha decidido no borrar el registro");
                return false;
            }
        }
    </script>
    <script>
    window.onload = function () {
        const params = new URLSearchParams(window.location.search);
        if (params.get("registro") === "ok") {
            const toastEl = document.getElementById('liveToast');
            const toast = new bootstrap.Toast(toastEl);
            toast.show();

            // Elimina el parámetro ?registro=ok de la URL sin recargar la página
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    };
</script>

</head>
<header>
    <nav class="navbar navbar-dark bg-dark text-white px-4" style="height: 70px;">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <span class="navbar-brand mb-0 h5">🗃️ ADMINISTRACION DE STOCK</span>
    <div class="d-flex align-items-center gap-3">
      <span>👤 Usuario: <strong><?php echo $_SESSION['usuario']?></strong></span>
      <span>🆔 Código: <strong><?php echo $_SESSION['idUsuario']?></strong></span>
    </div>
  </div>
</nav>
</header>
<body>
    <div style="min-height: 100vh;background-image: url('../imagenes/fondo4.jpg'); background-size: cover;  background-repeat: no-repeat; background-position: center; padding: 20px;">
    <!-- 
     -->

    <div class="content">
         <div class="container mt-5">
             <div class="row"> 
                <!-- Formulario -->
                <div class="col-md-3">
                    <h1><span class="badge bg-dark">Ingresar stock</span></h1>
                    <form action="insertar.php" method="POST">
                        <input type="text" class="form-control mb-3" name="nombre_" placeholder="nombre insumo" required>
                        <input type="text" class="form-control mb-3" name="unidadMedida_" placeholder="unidad de medida" required>
                        <input type="text" class="form-control mb-3" name="puntoReposicion_" placeholder="punto de reposicion" required>
                        <input type="text" class="form-control mb-3" name="cantidadDisponible_" placeholder="cantidad" required>
                        <input type="submit" class="btn btn-primary" value="Guardar" >
                       
                    
                    </form>
                </div>
                <!-- Tabla -->
                <div class="col-md-8">
                    <table id="stocks" class="table table-light table-striped table-bordered shadow-lg mt-4" style="width:100%">
                <thead class="bg-warning text-center">
                     <tr>
                     <th style="color:purple;">nombre insumo</th>
                     <th>unidad</th>
                     <th style="color:purple;">cantidad</th>
                     <th>reposicion</th>
                     <th style="color:purple;">fecha de actualizacion</th>
                     <th>administrador creador</th>
                     <th style="color:purple;">editar</th>
                     <th>borrar</th>
                     </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_row($result)) { ?>
                                <tr>
                                <td><?php echo htmlspecialchars($row[5]); ?></td> 
                               <td><?php echo htmlspecialchars($row[6]); ?></td> 
                               <td><?php echo htmlspecialchars($row[1]); ?></td>
                               <td><?php echo htmlspecialchars($row[2]); ?></td>
                               <td><?php echo htmlspecialchars($row[3]); ?></td>
                               <td><?php echo htmlspecialchars($row[4]); ?></td> 
                                <td class="text-center">
                                        <a href="actualizar.php?idInsumo=<?php echo urlencode($row[0]); ?>">
                                            <button type="button" class="btn btn-info">Editar</button>
                                        </a>
                                    </td>
                                    <td class="text-center">
                                        <a href="delete.php?idInsumo_=<?php echo urlencode($row[0]); ?>" onclick="return confirmDelete()">
                                            <button type="button" class="btn btn-danger">Eliminar</button>
                                        </a>
                                    </td>                                
                                </tr>
                                
                <?php } ?>

                </tbody>
                  
                  </table>

                </div>
    

       <div class="position-fixed bottom-0 start-0 m-3">
       <a href="../index.php" class="btn btn-secondary m-3">
       <i class="bi bi-arrow-left-circle"></i> volver atras
       </a>
       <a href="../login.html" class="btn btn-outline-primary">
       <i class="bi bi-house-door-fill"></i> cerrar sesion
       </a>
       </div>

             </div>
         </div>
    </div>
    
 <?php mysqli_close($conexion); ?>
 <!-- mensaje de exito de registro -->
 <div class="toast-container position-fixed bottom-0 end-0 p-3">
  <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-header bg-success text-white">
      <strong class="me-auto">Éxito</strong>
      <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Cerrar"></button>
    </div>
    <div class="toast-body">
      ¡Registro ingresado correctamente!
    </div>
  </div>
</div>


</body>

</html>