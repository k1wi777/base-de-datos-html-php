<?php
session_start(); 
include("conexion.php");
$con = conectar();
$id_insumo = $_GET['idInsumo']; // nombre correcto del parámetro
$sql = "SELECT stockinsumo.*,insumo.nombre,insumo.unidadMedida  FROM stockinsumo 
        INNER JOIN insumo ON  stockinsumo.idInsumo=insumo.idInsumo 
        WHERE stockinsumo.idInsumo = '$id_insumo'";
$query = mysqli_query($con, $sql);
$row = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>editar stock</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<header>
    <nav class="navbar navbar-dark bg-dark text-white px-4" style="height: 60px;">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <span class="navbar-brand mb-0 h5">✏️ ADMINISTRACION DE STOCK</span>
    <div class="d-flex align-items-center gap-3">
      <span>👤 Usuario: <strong><?php echo $_SESSION['usuario']?></strong></span>
      <span>🆔 Código: <strong><?php echo $_SESSION['idUsuario']?></strong></span>
    </div>
  </div>
</nav>
</header>
<body>
    <div style="min-height: 100vh;background-image: url('../imagenes/fondo3.jpg'); background-size: cover;  background-repeat: no-repeat; background-position: center; padding: 20px;">
    <!-- 
     -->

    <div class="container mt-5">
        <h1><span class="badge bg-dark">Editar datos de un insumo en stock</span></h1>
  
    <form action="update.php" method="POST">
        <div class="mb-3">
            <label><h6>id de insumo</h6></label>
             <input type="text" class="form-control" name="idInsumo_" value="<?php echo $row['idInsumo'] ?>" required>
        </div>
       
        <div class="mb-3">
            <label><h6>Nombre</h6></label>
            <input type="text" class="form-control" name="nombre_" value="<?php echo $row['nombre'] ?>" required>
        </div>

        <div class="mb-3">
            <label><h6>unidade de medida</h6></label>
            <input type="text" class="form-control" name="unidadMedida_" value="<?php echo $row['unidadMedida'] ?>" required>
        </div>
       <div class="mb-3">
            <label><h6>punto de reposicion</h6></label>
            <input type="text" class="form-control" name="puntoReposicion_" value="<?php echo $row['puntoReposicion'] ?>" required>
        </div>
        <div class="mb-3">
            <label><h6>cantidad disponible</h6></label>
            <input type="text" class="form-control" name="cantidadDisponible_" value="<?php echo $row['cantidadDisponible'] ?>" required>
        </div>

        <input type="submit" class="btn btn-primary" value="Actualizar">
        <a href="stock.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
</div>
</body>
</html>