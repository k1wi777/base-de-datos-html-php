<?php 
// Conexión a base de datos
session_start();

include("conexion.php");
$con = conectar();

$usuario = $_POST['usuario'];
$clave = $_POST['clave'];

$sql = "SELECT usuario.*,administrador.idUsuario
 FROM usuario 
 JOIN administrador 
 ON usuario.idUsuario = administrador.idUsuario 
 WHERE usuario.nombreUsuario='$usuario' AND usuario.contraseña='$clave'";
$query = mysqli_query($con, $sql);

$sql2 = "SELECT usuario.*,vendedor.idUsuario
 FROM usuario 
 JOIN vendedor 
 ON usuario.idUsuario = vendedor.idUsuario 
 WHERE usuario.nombreUsuario='$usuario' AND usuario.contraseña='$clave'";
$query2 = mysqli_query($con, $sql2);

if (mysqli_num_rows($query) > 0) {
    $row = mysqli_fetch_assoc($query);
    $_SESSION['usuario'] = $usuario;
     $_SESSION['idUsuario'] = $row['idUsuario']; 
    header("Location: index.php"); 
} else if(mysqli_num_rows($query2) > 0){
    $row = mysqli_fetch_assoc($query2);
     $_SESSION['usuario'] = $usuario;
      $_SESSION['idUsuario'] = $row['idUsuario']; 
    header("Location: vendedor.php"); 

} else {
    echo "<script>
        alert('Usuario o contraseña incorrectos');
        window.location.href = 'login.html';
    </script>";
}
?>