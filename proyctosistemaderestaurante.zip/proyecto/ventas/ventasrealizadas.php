<?php
session_start();
include("../conexion.php");
$con = conectar();
 $idVendedor_=$_SESSION['idUsuario'];
 $result = mysqli_query($con,"SELECT *FROM venta  where venta.idVendedor= '$idVendedor_'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ventas realizadas</title>
    <!-- Incluye Bootstrap Icons  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

                 <!-- Bootstrap 5 CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                 <!-- Bootstrap 5 JS -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
     <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">

     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
      <style>
        
            thead.bg-purple th {
            background-color: #6f42c1 !important;
            color: white !important;
            }
            table tbody tr:hover {
            background-color: #f3e8ff !important;
            cursor: pointer;
             }
              .table-percon{
                background: transparent;
              border:2px solid rgba(255,255,255,.2);
              border-radius: 15px;
              backdrop-filter: blur(20px);
              box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
              padding: 25px;
            }
         </style>
          <script>
        $(document).ready(function() {
            $('#ventas').DataTable({
                "lengthMenu": [[5, 10, 50, -1], [5, 10, 50, "Todos"]]
            });
        });
    </script>
</head>
<body>
  <div style="min-height: 100vh;background-image: url('../ventasrealizadas.jpg'); background-size: cover;  background-repeat: no-repeat; background-position: center; padding: 20px;">
    
     <div class="content">
         <div class="container mt-2">
            <div class="row">
                <!-- Tabla -->
             <div class="col-md-15">
            <div class="table-percon">  
               <h1><span class="badge bg-dark">ventas realizadas por :' <?php echo $_SESSION['usuario']?> '</span></h1>
               <!-- Tabla mejorada -->
               <table id="ventas" class="table table-striped table-bordered table-hover shadow-lg mt-4">
                 <thead class="bg-purple text-center">
                   <tr>
                     <th >ID Venta</th>
                     <th>Total</th>
                     <th>Fecha y hora</th>
                     <th>detalles</th>
                   </tr>
                 </thead>
                 <tbody>
                   <?php while($row = mysqli_fetch_assoc($result)) { ?>
                   <tr>
                     <td><?php echo htmlspecialchars($row['idVenta']); ?></td>
                     <td><?php echo htmlspecialchars($row['totalVenta']); ?></td>
                     <td><?php echo htmlspecialchars($row['fechaHora']); ?></td>
                     <td class="text-center">
                          <a href="detallesVenta.php?idVenta=<?php echo urlencode($row['idVenta']); ?>">
                             <button type="button" class="btn btn-info">mostrar</button>
                          </a>
                     </td>
                     
                   </tr>
                   <?php } ?>
                 </tbody>
               </table>
                   </div>        
        </div>
     <div class="position-fixed bottom-0 start-0 m-3">
       <a href="../vendedor.php" class="btn btn-secondary me-3">
       <i class="bi bi-arrow-left-circle"></i> volver atras
       </a>
       <a href="../login.html" class="btn btn-outline-primary">
       <i class="bi bi-house-door-fill"></i> cerrar sesion
       </a>
     </div>
    </div>
  </div>
   <?php mysqli_close($con); ?>
</body>
</html>