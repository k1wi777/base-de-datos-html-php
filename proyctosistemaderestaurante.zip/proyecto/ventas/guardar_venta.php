<?php
session_start();
include("../conexion.php");
$con = conectar();

if (!isset($_SESSION['idUsuario'])) {
    echo json_encode(['status' => 'error', 'mensaje' => 'No has iniciado sesión.']);
    exit;
}

$idVendedor = $_SESSION['idUsuario'];
$productos = [];

for ($i = 0; isset($_POST['idProducto'][$i]); $i++) {
    $productos[] = [
        'idProducto' => $_POST['idProducto'][$i],
        'cantidad' => $_POST['cantidad'][$i],
        'subtotal' => $_POST['subtotal'][$i]
    ];
}

$fechaHora = date('Y-m-d H:i:s');
$soloFecha = date('Y-m-d');
$total = 0;

foreach ($productos as $producto) {
    $total += floatval($producto['subtotal']);
}

// 1. Insertar en 'venta'
$sqlVenta = "INSERT INTO venta (fechaHora, idVendedor, totalVenta) VALUES (?, ?, ?)";
$stmtVenta = $con->prepare($sqlVenta);
$stmtVenta->bind_param("sid", $fechaHora, $idVendedor, $total);

if (!$stmtVenta->execute()) {
    echo json_encode(['status' => 'error', 'mensaje' => 'Error al registrar la venta']);
    exit;
}
$idVenta = $stmtVenta->insert_id;

// 2. Insertar en 'reporteventa'
$sqlReporte = "INSERT INTO reporteventa (fecha) VALUES (?)";
$stmtReporte = $con->prepare($sqlReporte);
$stmtReporte->bind_param("s", $soloFecha);

if (!$stmtReporte->execute()) {
    echo json_encode(['status' => 'error', 'mensaje' => 'Error al registrar en reporte de venta']);
    exit;
}
$idReporte = $stmtReporte->insert_id;

// 3. Insertar en 'incluye'
$sqlIncluye = "INSERT INTO incluye (idReporte, idVenta) VALUES (?, ?)";
$stmtIncluye = $con->prepare($sqlIncluye);
$stmtIncluye->bind_param("ii", $idReporte, $idVenta);

if (!$stmtIncluye->execute()) {
    echo json_encode(['status' => 'error', 'mensaje' => 'Error al relacionar venta con el reporte']);
    exit;
}

// 4. Insertar los detalles de los productos en 'detalleVenta'
$sqlDetalle = "INSERT INTO detalleVenta (idVenta, idProducto, cantidad, subtotal) VALUES (?, ?, ?, ?)";
$stmtDetalle = $con->prepare($sqlDetalle);

foreach ($productos as $producto) {
    $idProducto = $producto['idProducto'];
    $cantidad = $producto['cantidad'];
    $subtotal = $producto['subtotal'];

    $stmtDetalle->bind_param("iiid", $idVenta, $idProducto, $cantidad, $subtotal);
    $stmtDetalle->execute();
}

echo json_encode(['status' => 'success', 'mensaje' => 'Venta registrada correctamente.']);
?>
