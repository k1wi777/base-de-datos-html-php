<?php
session_start();
include("../conexion.php");
$con = conectar();

 // Consulta para llenar el combo de insumos
    $result2 = mysqli_query($con, "SELECT * FROM producto") or die('No pudo conectar a la consulta');
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Realizar Venta</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body {
       background-image: url(../gestion2.jpg); 
       background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
    }
    .venta-container {
      display: flex;
      justify-content: space-between;
      padding: 20px;
    }
    .formulario-producto, .tabla-venta {
      width: 48%;
    }
    .boton-realizar {
      position: fixed;
      bottom: 20px;
      right: 20px;
    }
    .bg-fondo {
  background: transparent;
  border:2px solid rgba(255,255,255,.2);
  border-radius: 15px;
  backdrop-filter: blur(20px);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  padding: 25px;
}
* {
  box-sizing: border-box;
}
.tabla-venta {
   width: 48%;
  padding: 25px;
   background: transparent;
  border:2px solid rgba(255,255,255,.2);
   backdrop-filter: blur(7px);
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  border-radius: 15px;
}
    thead.bg-purple th {
            background-color:rgb(136, 104, 196) !important;
            color: white !important;
            }

            table tbody tr:hover {
            background-color:rgb(148, 106, 194) !important;
            cursor: pointer;
             }
  </style>
</head>
<body>
<div class="venta-container">
  <!-- Formulario de producto -->
  <div class="formulario-producto">
    <h1><span class="badge bg-dark">Agregar producto</span></h1>
    <div class="bg-fondo">
    <form id="formAgregarProducto">
      <div class="mb-3">
        <label for="idProducto" class="form-label">Producto</label>
        <select name="idProducto" id="idProducto" class="form-control" required>
          <?php while ($valores = mysqli_fetch_array($result2)) { ?>
            <option value="<?php echo $valores['idProducto']; ?>" data-precio="<?php echo $valores['precio']; ?>">
             <?php echo $valores['nombre']; ?>
           </option>
          <?php } ?>
        </select>
      </div>
      <div class="mb-3">
        <label for="cantidad" class="form-label">Cantidad</label>
        <input type="number" name="cantidad" id="cantidad" class="form-control" required min="1">
      </div>
      
      <input type="hidden" name="precio" id="precio"> <!-- opcional -->
      <input type="hidden" name="subtotal" id="subtotal">
      <button type="submit" class="btn btn-primary">Agregar producto</button>
    </form>
    </div>
  </div>

  <!-- Tabla de productos agregados -->
  <div class="tabla-venta">
     <h1><span class="badge bg-dark">Productos en la venta</span></h1>
   
    <table class="table table-bordered" id="tablaVenta">
      <thead class="bg-purple text-center">
        <tr>
          <th>Producto</th>
          <th>Cantidad</th>
          <th>Subtotal</th>
          <th>Acciones</th>
          
        </tr>
      </thead>
      <tbody>
        <!-- Las filas se agregan dinámicamente con JavaScript -->
      </tbody>
       <tfoot>
    <tr>
      <td colspan="2" class="text-end"><strong>Total:</strong></td>
      <td colspan="2" id="totalVenta" class="text-start">$0.00</td>
    </tr>
  </tfoot>
    </table>
   
  </div>
</div>
<input type="hidden" name="total" id="total">
<!-- Botón de realizar venta -->
<div class="boton-realizar">
  <button class="btn btn-success" id="realizarVenta">Realizar venta</button>
 </div>
 <!-- Botón para retroceder -->
 <div class="position-fixed bottom-0 start-0 m-3">
       <a href="../vendedor.php" class="btn btn-secondary me-2">
       <i class="bi bi-arrow-left-circle"></i> volver atras
       </a>
       <a href="../login.html" class="btn btn-outline-primary">
       <i class="bi bi-house-door-fill"></i> cerrar sesion
       </a>
       </div>
    </div>

<script>
  const form = document.getElementById('formAgregarProducto');
  const tabla = document.getElementById('tablaVenta').querySelector('tbody');
  const productosAgregados = {};

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const select = document.getElementById('idProducto');
    const idProducto = select.value;
    const nombreProducto = select.options[select.selectedIndex].text;
    const precio = parseFloat(select.options[select.selectedIndex].dataset.precio);
    const cantidad = parseInt(document.getElementById('cantidad').value);
    const subtotal = (precio * cantidad).toFixed(2);

    if (productosAgregados[idProducto]) {
      alert("Este producto ya fue agregado. Puedes editar la cantidad.");
      return;
    }

    document.getElementById('precio').value = precio;
    document.getElementById('subtotal').value = subtotal;

    productosAgregados[idProducto] = { cantidad, subtotal, precio };

    const fila = document.createElement('tr');
    fila.setAttribute('data-id', idProducto);
    fila.innerHTML = `
      <td>${nombreProducto}</td>
      <td class="cantidad">${cantidad}</td>
      <td class="subtotal">${subtotal}</td>
      <td>
        <button class="btn btn-warning btn-sm editar">Editar</button>
        <button class="btn btn-danger btn-sm eliminar">Eliminar</button>
      </td>
    `;
    tabla.appendChild(fila);
    actualizarTotal();
  });

  tabla.addEventListener('click', function (e) {
    if (e.target.classList.contains('editar')) {
      const fila = e.target.closest('tr');
      const id = fila.getAttribute('data-id');
      const nuevaCantidad = prompt("Ingrese nueva cantidad:", productosAgregados[id].cantidad);
      if (nuevaCantidad && nuevaCantidad > 0) {
        const cantidad = parseInt(nuevaCantidad);
        const subtotal = (productosAgregados[id].precio * cantidad).toFixed(2);
        productosAgregados[id].cantidad = cantidad;
        productosAgregados[id].subtotal = subtotal;
        fila.querySelector('.cantidad').textContent = cantidad;
        fila.querySelector('.subtotal').textContent = subtotal;
      }
      actualizarTotal();
    } else if (e.target.classList.contains('eliminar')) {
      const fila = e.target.closest('tr');
      const id = fila.getAttribute('data-id');
      delete productosAgregados[id];
      fila.remove();
      actualizarTotal();
    }
  });
  function actualizarTotal() {
  let total = 0;
  Object.values(productosAgregados).forEach(p => {
    total += parseFloat(p.subtotal);
  });
  document.getElementById('totalVenta').textContent = `$${total.toFixed(2)}`;
  }

  document.getElementById('realizarVenta').addEventListener('click', function () {
    const filas = document.querySelectorAll('#tablaVenta tbody tr');
    if (filas.length === 0) {
      alert('No hay productos agregados a la venta.');
      return;
    }

    const formData = new FormData();

    filas.forEach(fila => {
      const idProducto = fila.getAttribute('data-id');
      const cantidad = fila.querySelector('.cantidad').textContent.trim();
      const subtotal = fila.querySelector('.subtotal').textContent.trim();

      formData.append('idProducto[]', idProducto);
      formData.append('cantidad[]', cantidad);
      formData.append('subtotal[]', subtotal);
    });

    fetch('guardar_venta.php', {
      method: 'POST',
      body: formData
    })
    .then(response => response.json())
    .then(data => {
      if (data.status === 'success') {
        alert(data.mensaje);
        location.reload();
      } else {
        alert('Error: ' + data.mensaje);
      }
    })
    .catch(error => {
      console.error('Error en la solicitud:', error);
      alert('Ocurrió un error al registrar la venta.');
    });
  });
</script>
</body>
</html>
