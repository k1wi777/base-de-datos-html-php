<?php

include("conexion.php");
$con=conectar();

$idReporte_=$_GET['idReporte'];
 $result = mysqli_query($con,"SELECT idVenta FROM incluye where idReporte= '$idReporte_'");
    $row = mysqli_fetch_assoc($result);
  $idVenta_=  $row['idVenta'];/*guardo el id venta que esta relacionado con ese reporte de venta */
$sql="DELETE FROM incluye  WHERE idReporte='$idReporte_'";/* borro el incluye*/
$sql0="DELETE FROM reporteVenta  WHERE idReporte='$idReporte_'";
$sql1="DELETE FROM detalleVenta  WHERE idVenta='$idVenta_'";/* borro el detalle de la venta*/
$sql2="DELETE FROM venta  WHERE idVenta='$idVenta_'";
$query=mysqli_query($con,$sql);
$query0=mysqli_query($con,$sql0);
$query1=mysqli_query($con,$sql1);
$query2=mysqli_query($con,$sql2);
if($query and $query0 and $query1 and $query2)
{ 
Header("Location: reporteVentas.php");
}
?>

