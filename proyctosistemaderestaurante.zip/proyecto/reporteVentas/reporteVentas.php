<?php
 session_start(); 
include("conexion.php");
 $conexion = conectar();
     $result = mysqli_query($conexion,"SELECT 
    reporteVenta.*, 
    incluye.idVenta, 
    venta.*
    FROM reporteVenta
    JOIN incluye ON reporteVenta.idReporte = incluye.idReporte
    JOIN venta ON incluye.idVenta = venta.idVenta");
    


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>reporte ventas</title>
     <!-- Incluye Bootstrap Icons  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

                 <!-- Bootstrap 5 CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                 <!-- Bootstrap 5 JS -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
     <link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/dataTables.bootstrap5.min.css">

     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
     <script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.13.5/js/dataTables.bootstrap5.min.js"></script>
         <style>
            thead.bg-purple th {
            background-color: #6f42c1 !important;
            color: white !important;
            }
            table tbody tr:hover {
            background-color: #f3e8ff !important;
            cursor: pointer;
             }
         </style>
      <script type="text/javascript">
        function confirmDelete() {
            var respuesta = confirm("¿Seguro que desea borrar?");
            if (respuesta) {
                alert("Registro Borrado");
                return true;
            } else {
                alert("Ha decidido no borrar el registro");
                return false;
            }
        }
    </script>
    <!-- Script DataTables + filtro -->
<script>
$(document).ready(function() {
    const table = $('#ventas').DataTable({
        language: { url: 'https://cdn.datatables.net/plug-ins/1.13.5/i18n/es-ES.json' },
        order: [[0, 'desc']]
    });

    $('#filterVendedor').on('change', function() {
        table.column(2).search(this.value).draw();
    });
});
</script>
   
</head>
<header>
    <nav class="navbar navbar-dark bg-dark text-white px-4" style="height: 60px;">
  <div class="container-fluid d-flex justify-content-between align-items-center">
    <span class="navbar-brand mb-0 h5">🗃️ REPORTE DE VENTAS</span>
    <div class="d-flex align-items-center gap-3">
      <span>👤 Usuario: <strong><?php echo $_SESSION['usuario']?></strong></span>
      <span>🆔 Código: <strong><?php echo $_SESSION['idUsuario']?></strong></span>
    </div>
  </div>
</nav>
</header>
<body>
  <div style="min-height: 100vh;background-image: url('ventas.jpg'); background-size: cover;  background-repeat: no-repeat; background-position: center; padding: 20px;">
    
     <div class="content">
         <div class="container mt-2">
            <div class="row">
                <!-- Tabla -->
             <div class="col-md-15">
               <!-- Combobox de filtro -->
               <label for="filterVendedor">Filtrar por vendedor:</label>
               <select id="filterVendedor" class="form-select w-auto mb-3">
                 <option value="">Todos</option>
                 <?php
                 $resVen = mysqli_query($conexion, "SELECT DISTINCT idVendedor FROM venta");
                 while ($v = mysqli_fetch_assoc($resVen)) {
                     echo "<option value=\"{$v['idVendedor']}\">{$v['idVendedor']}</option>";
                 }
                 ?>
               </select>

               <!-- Tabla mejorada -->
               <table id="ventas" class="table table-striped table-bordered table-hover shadow-lg mt-4">
                 <thead class="bg-purple text-center">
                   <tr>
                     <th >ID Venta</th>
                     <th>Total</th>
                     <th >ID Vendedor</th>
                     <th>Fecha y hora</th>
                     <th>detalles</th>
                     <th>borrar</th>
                   </tr>
                 </thead>
                 <tbody>
                   <?php while($row = mysqli_fetch_assoc($result)) { ?>
                   <tr>
                     <td><?php echo htmlspecialchars($row['idVenta']); ?></td>
                     <td><?php echo htmlspecialchars($row['totalVenta']); ?></td>
                     <td><?php echo htmlspecialchars($row['idVendedor']); ?></td>
                     <td><?php echo htmlspecialchars($row['fechaHora']); ?></td>
                     <td class="text-center">
                          <a href="detallesVenta.php?idVenta=<?php echo urlencode($row['idVenta']); ?>">
                             <button type="button" class="btn btn-info">mostrar</button>
                          </a>
                     </td>
                     <td class="text-center">
                       <a href="delete.php?idReporte=<?php echo urlencode($row['idReporte']); ?>" onclick="return confirmDelete()">
                         <button type="button" class="btn btn-danger">Eliminar</button>
                       </a>
                     </td>
                   </tr>
                   <?php } ?>
                 </tbody>
               </table>
                    
        </div>
     <div class="position-fixed bottom-0 start-0 m-3">
       <a href="../index.php" class="btn btn-secondary m-3">
       <i class="bi bi-arrow-left-circle"></i> volver atras
       </a>
       <a href="../login.html" class="btn btn-outline-primary">
       <i class="bi bi-house-door-fill"></i> cerrar sesion
       </a>
     </div>
    </div>
  </div>
   <?php mysqli_close($conexion); ?>
</body>
</html>